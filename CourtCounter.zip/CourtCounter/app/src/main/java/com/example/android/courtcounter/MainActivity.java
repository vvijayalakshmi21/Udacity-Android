package com.example.android.courtcounter;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.lang.*;

public class MainActivity extends AppCompatActivity {

    int scoreTeamA = 0;
    int scoreTeamB = 0;
    double teamAOvers = 0;
    double teamBOvers = 0;
    int teamAWickets = 0;
    int teamBWickets = 0;

    private TextView teamA;
    private TextView teamB;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        teamA = (TextView) findViewById(R.id.teamAScore);
        teamB = (TextView) findViewById(R.id.teamBScore);
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {

        String teamASavedScore = teamA.getText().toString();
        String teamBSavedScore = teamB.getText().toString();

        // Save UI state changes to the savedInstanceState.
        // This bundle will be passed to onCreate if the process is
        // killed and restarted.

        savedInstanceState.putString("scoreTeamA", teamASavedScore);
        savedInstanceState.putString("scoreTeamB", teamBSavedScore);

        //Score Variables
        savedInstanceState.putInt("teamAScoreVariable", scoreTeamA);
        savedInstanceState.putInt("teamBScoreVariable", scoreTeamB);

        savedInstanceState.putInt("teamAWicketVariable", teamAWickets);
        savedInstanceState.putInt("teamBWicketVariable", teamBWickets);

        savedInstanceState.putDouble("teamAOverVariable", teamAOvers);
        savedInstanceState.putDouble("teamBOverVariable", teamBOvers);


        Log.i("onSaveInstanceState", "teamASavedScore : "
                + teamASavedScore + ", teamBSavedScore : "
                + teamBSavedScore + ", teamAScoreVariable : "
                + scoreTeamA + ", teamBScoreVariable : " + scoreTeamB
                + ", teamAWickets : " + teamAWickets + ", teamBWickets : "
                + teamBWickets + ", teamAOvers : " + teamAOvers + ", teamBOvers : " + teamBOvers);
        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {

        super.onRestoreInstanceState(savedInstanceState);

        // Restore UI state from the savedInstanceState.
        // This bundle has also been passed to onCreate.

        String teamASavedScore = savedInstanceState.getString("scoreTeamA");
        String teamBSavedScore = savedInstanceState.getString("scoreTeamB");

        teamAOvers = savedInstanceState.getDouble("teamAOverVariable");
        teamBOvers = savedInstanceState.getDouble("teamBOverVariable");
        teamAWickets = savedInstanceState.getInt("teamAWicketVariable");
        teamBWickets = savedInstanceState.getInt("teamBWicketVariable");
        scoreTeamA = savedInstanceState.getInt("teamAScoreVariable");
        scoreTeamB = savedInstanceState.getInt("teamBScoreVariable");

        Log.i("onRestoreInstanceState", "teamASavedScore : "
                + teamASavedScore + ", teamBSavedScore : "
                + teamBSavedScore + ", teamAScoreVariable : "
                + scoreTeamA + ", teamBScoreVariable : " + scoreTeamB
                + ", teamAWickets : " + teamAWickets + ", teamBWickets : "
                + teamBWickets + ", teamAOvers : " + teamAOvers + ", teamBOvers : " + teamBOvers);

        teamA.setText(teamASavedScore);
        teamB.setText(teamBSavedScore);
    }

    private void display(int runs, boolean teamA) {

        int resourceId = 0;
        double overs = 0.0;
        int wickets = 0;
        String text = "";

        if (teamA) {
            resourceId = R.id.teamAScore;
            overs = teamAOvers;
            wickets = teamAWickets;
        } else {
            resourceId = R.id.teamBScore;
            overs = teamBOvers;
            wickets = teamBWickets;
        }

        TextView score = (TextView) findViewById(resourceId);

        DecimalFormat df = new DecimalFormat("#.#");
        df.setRoundingMode(RoundingMode.FLOOR);
        overs = Double.valueOf(df.format(overs));

        Log.i("display", "before if, overs : " + overs);
        if (overs > (Math.floor(overs) + 0.5)) {
            overs = Math.ceil(overs);
            if (teamA) {
                teamAOvers = overs;
            } else {
                teamBOvers = overs;
            }
            Log.i("display", "inside if condition, overs : " + overs);
        }

        Log.i("display", "after if, overs : " + overs);
        text = String.format("%s/%d        (%.1f)", runs, wickets, overs);
        score.setText(text);
    }

    public void addSixToTeamA(View view) {
        scoreTeamA = scoreTeamA + 6;
        teamAOvers += 0.1;
        display(scoreTeamA, true);
    }

    public void addFourToTeamA(View view) {
        scoreTeamA = scoreTeamA + 4;
        teamAOvers += 0.1;
        display(scoreTeamA, true);
    }

    public void addOneWicketToTeamA(View view) {
        teamAWickets += 1;
        teamAOvers += 0.1;
        display(scoreTeamA, true);
    }

    public void addSixToTeamB(View view) {
        scoreTeamB = scoreTeamB + 6;
        teamBOvers += 0.1;
        display(scoreTeamB, false);
    }

    public void addFourToTeamB(View view) {
        scoreTeamB = scoreTeamB + 4;
        teamBOvers += 0.1;
        display(scoreTeamB, false);
    }

    public void addOneWicketToTeamB(View view) {
        teamBWickets += 1;
        teamBOvers += 0.1;
        display(scoreTeamB, false);
    }

    public void resetScores(View view) {
        AlertDialog.Builder adb = new AlertDialog.Builder(this);

        //Set Dialog properties
        adb.setTitle("Reset Scores");
        adb.setMessage("Do you really want to reset the scores?");
        adb.setIcon(R.drawable.reseticon);

        adb.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                scoreTeamA = 0;
                teamAOvers = 0;
                teamAWickets = 0;
                display(scoreTeamA, true);
                scoreTeamB = 0;
                teamBOvers = 0;
                teamBWickets = 0;
                display(scoreTeamB, false);

                Toast.makeText(getApplicationContext(), "Scores reset", Toast.LENGTH_SHORT).show();
            }
        });

        adb.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        adb.show();
    }
}
