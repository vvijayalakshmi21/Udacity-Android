package com.example.ragavivera.musicstructureapp;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

public class AlbumDetailsActivity extends AppCompatActivity  implements TabLayout.OnTabSelectedListener{

    //This is our tab layout
    private TabLayout tabLayout;

    //This is our viewPager
    private ViewPager viewPager;

    private TabAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album_details);

        //Initializing the tab layout
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);

        //Initializing viewPager
        viewPager = (ViewPager) findViewById(R.id.viewPager);

        adapter = new TabAdapter(getSupportFragmentManager());
        adapter.addFragment(new AlbumDetailsTab(), "Description");
        adapter.addFragment(new ViewSongsTab(), "Songs");

        viewPager.setAdapter(adapter);
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        tabLayout.setupWithViewPager(viewPager);
    }

    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        viewPager.setCurrentItem(tab.getPosition());
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {
    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {
    }
}
