package com.example.ragavivera.musicstructureapp;

import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class AlbumDetailsTab extends Fragment {

    MusicAlbum albumDetails;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //Returning the layout file after inflating
        View view = inflater.inflate(R.layout.tab_album_details, container, false);
        albumDetails = (MusicAlbum) getActivity().getIntent().getParcelableExtra("MusicAlbumSelected");

        if (albumDetails != null) {

            TextView albumName = view.findViewById(R.id.album_name);
            albumName.setText(albumDetails.getAlbumName());

            ImageView albumCover = view.findViewById(R.id.album_cover);
            albumCover.setImageResource(albumDetails.getAlbumCover());

            TextView directorName = view.findViewById(R.id.director_name);
            String directedBy = "<b> Directed by : </b>" + albumDetails.getDirectorName();
            directorName.setText(Html.fromHtml(directedBy));

            TextView imdbRating = view.findViewById(R.id.imdb_rating);
            String rating = "<b> IMDB Rating : </b>";
            imdbRating.setText(Html.fromHtml(rating + albumDetails.getIMDBRating()));

            TextView yearRelease = view.findViewById(R.id.album_year);
            String year = "<b> Year of Release : </b>";
            yearRelease.setText(Html.fromHtml(year + albumDetails.getAlbumYear()));
        }
        return view;
    }
}
