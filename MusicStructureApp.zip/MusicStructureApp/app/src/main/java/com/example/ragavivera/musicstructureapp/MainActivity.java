package com.example.ragavivera.musicstructureapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Create an ArrayList of MusicAlbum objects
        final ArrayList<MusicAlbum> musicAlbum = new ArrayList<>();

        ArrayList<ViewSongs> jeansSongs = new ArrayList<>();
        jeansSongs.add(new ViewSongs("Poovukkul Olindirukum", "5:32", "Chithra, Hariharan"));
        jeansSongs.add(new ViewSongs("Haira Haira", "2:44", "Sujatha, SPB"));
        musicAlbum.add(new MusicAlbum("Jeans", R.drawable.jeans, "1998", "Shankar","7.5/10", jeansSongs));

        ArrayList<ViewSongs> indianSongs = new ArrayList<>();
        indianSongs.add(new ViewSongs("Telephone Manipol", "3:09", "Chithra, SPB"));
        indianSongs.add(new ViewSongs("Kappaleri Poyachu", "4:54", "Sujatha, Hariharan"));
        musicAlbum.add(new MusicAlbum("Indian", R.drawable.indian, "2000","Shankar", "8.5/10", indianSongs));

        ArrayList<ViewSongs> muthalvanSongs = new ArrayList<>();
        muthalvanSongs.add(new ViewSongs("Uppu Karuvadu", "4:20", "Harini, Sankar Mahadevan"));
        muthalvanSongs.add(new ViewSongs("Shakalaka baby", "5:12", "Vasundara Das"));
        musicAlbum.add(new MusicAlbum("Muthalvan", R.drawable.muthalvan, "2002", "Shankar", "9/10", muthalvanSongs));

        ArrayList<ViewSongs> rojaSongs = new ArrayList<>();
        rojaSongs.add(new ViewSongs("Pudhu Vellai mazhai", "6:08", "Unni Menon, Sujatha"));
        rojaSongs.add(new ViewSongs("Kadhal Rojave", "3:44", "SP Balasubramaniyam"));
        musicAlbum.add(new MusicAlbum("Roja", R.drawable.roja, "1996", "Maniratnam", "8/10",rojaSongs));

        MusicAlbumAdapter albumAdapter = new MusicAlbumAdapter(this, musicAlbum);

        // Get a reference to the ListView, and attach the adapter to the listView.
        ListView listView = (ListView) findViewById(R.id.listview_album);
        listView.setAdapter(albumAdapter);

        //Attach a listener on the list view items for displaying album details
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, AlbumDetailsActivity.class);
                MusicAlbum musicAlbumSelected = musicAlbum.get(position);
                intent.putExtra("MusicAlbumSelected", musicAlbumSelected);
                startActivity(intent);
            }
        });
    }
}
