package com.example.ragavivera.musicstructureapp;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class MusicAlbum implements Parcelable{
    private String mAlbumName;
    private int mAlbumCoverResourceId;
    private String mYearOfRelease;
    private String mDirectorName;
    private String mIMDBRating;
    private ArrayList<ViewSongs> mSongs = new ArrayList<>();

    public MusicAlbum(String albumName, int coverResourceId, String yearOfRelease, String directorName, String IMDBRating, ArrayList<ViewSongs> songs){
        mAlbumName = albumName;
        mAlbumCoverResourceId =  coverResourceId;
        mYearOfRelease = yearOfRelease;
        mDirectorName = directorName;
        mIMDBRating = IMDBRating;
        mSongs = songs;
    }

    public String getAlbumName(){
        return mAlbumName;
    }

    public int getAlbumCover(){
        return mAlbumCoverResourceId;
    }

    public String getAlbumYear(){
        return mYearOfRelease;
    }

    public String getDirectorName(){
        return mDirectorName;
    }

    public String getIMDBRating(){
        return mIMDBRating;
    }

    public ArrayList<ViewSongs> getSongs() { return mSongs;}

    //parcel part
    public MusicAlbum(Parcel in){
        String[] data = new String[5];
        in.readStringArray(data);
        this.mAlbumName = data[0];
        this.mAlbumCoverResourceId=Integer.parseInt(data[1]);
        this.mYearOfRelease=data[2];
        this.mDirectorName=data[3];
        this.mIMDBRating=data[4];
        in.readTypedList(mSongs, ViewSongs.CREATOR);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeStringArray(new String[]{this.mAlbumName,String.valueOf(this.mAlbumCoverResourceId),this.mYearOfRelease, this.mDirectorName, this.mIMDBRating});
        dest.writeTypedList(mSongs);
    }

    public static final Parcelable.Creator<MusicAlbum> CREATOR= new Parcelable.Creator<MusicAlbum>() {

        @Override
        public MusicAlbum createFromParcel(Parcel source) {
            // TODO Auto-generated method stub
            return new MusicAlbum(source);  //using parcelable constructor
        }

        @Override
        public MusicAlbum[] newArray(int size) {
            // TODO Auto-generated method stub
            return new MusicAlbum[size];
        }
    };
}
