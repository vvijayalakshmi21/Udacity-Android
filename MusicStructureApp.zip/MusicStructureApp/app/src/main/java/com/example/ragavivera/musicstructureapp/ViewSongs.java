package com.example.ragavivera.musicstructureapp;

import android.os.Parcel;
import android.os.Parcelable;

public class ViewSongs implements Parcelable{
    private String mSongName;
    private String mSongDuration;
    private String mSingers;

    public ViewSongs(String songName, String songDuration, String singers) {
        mSongName = songName;
        mSongDuration = songDuration;
        mSingers = singers;
    }

    public String getSongName(){
        return mSongName;
    }

    public String getSongDuration(){ return mSongDuration; }

    public String getSingers(){
        return mSingers;
    }

    //parcel part
    public ViewSongs(Parcel in){
        String[] data= new String[3];

        in.readStringArray(data);
        this.mSongName= data[0];
        this.mSongDuration =data[1];
        this.mSingers=data[2];
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeStringArray(new String[]{this.mSongName,this.mSongDuration, this.mSingers});
    }

    public static final Creator<ViewSongs> CREATOR= new Creator<ViewSongs>() {

        @Override
        public ViewSongs createFromParcel(Parcel source) {
            // TODO Auto-generated method stub
            return new ViewSongs(source);  //using parcelable constructor
        }

        @Override
        public ViewSongs[] newArray(int size) {
            // TODO Auto-generated method stub
            return new ViewSongs[size];
        }
    };
}

