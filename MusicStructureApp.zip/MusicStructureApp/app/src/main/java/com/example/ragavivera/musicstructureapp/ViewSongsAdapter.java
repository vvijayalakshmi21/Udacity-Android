package com.example.ragavivera.musicstructureapp;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class ViewSongsAdapter extends ArrayAdapter<ViewSongs> {

    public ViewSongsAdapter(Activity context, ArrayList<ViewSongs> viewSongs) {
        super(context, 0, viewSongs);
    }

    @Override
    @NonNull
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        // Check if the existing view is being reused, otherwise inflate the view
        View listItemView = convertView;
        if(listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_songs, parent, false);
        }

        // Get the {@link AndroidFlavor} object located at this position in the list
        ViewSongs currentSong = getItem(position);

        // Find the TextView in the list_albumsms.xml layout with the ID version_name
        TextView songNameTextView = (TextView) listItemView.findViewById(R.id.song_name);
        // Get the version name from the current AndroidFlavor object and
        // set this text on the name TextView
        songNameTextView.setText(currentSong.getSongName());

        // Find the TextView in the list_albumsms.xml layout with the ID version_number
        TextView songDurationTextView = (TextView) listItemView.findViewById(R.id.song_duration);
        // Get the version number from the current AndroidFlavor object and
        // set this text on the number TextView
        songDurationTextView.setText(currentSong.getSongDuration());

        // Find the ImageView in the list_albumsms.xml layout with the ID list_item_icon
        TextView singersTextView = (TextView) listItemView.findViewById(R.id.singers);
        // Get the image resource ID from the current AndroidFlavor object and
        // set the image to iconView
        singersTextView.setText(currentSong.getSingers());

        // Return the whole list item layout (containing 2 TextViews and an ImageView)
        // so that it can be shown in the ListView
        return listItemView;
    }
}
