package com.example.ragavivera.musicstructureapp;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class ViewSongsTab extends Fragment {

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.tab_view_songs, container, false);

        // Create an ArrayList of MusicAlbum objects
        MusicAlbum albumDetails = (MusicAlbum) getActivity().getIntent().getParcelableExtra("MusicAlbumSelected");

        //Get the songs list for the selected album
        final ArrayList<ViewSongs> viewSongs = albumDetails.getSongs();
        ViewSongsAdapter viewSongAdapter = new ViewSongsAdapter(getActivity(), viewSongs);

        // Get a reference to the ListView, and attach the adapter to the listView.
        ListView listView = (ListView) view.findViewById(R.id.listview_songs);
        listView.setAdapter(viewSongAdapter);

        //Returning the layout file after inflating
        //Change R.layout.tab1 in you classes
        return view;
    }
}
